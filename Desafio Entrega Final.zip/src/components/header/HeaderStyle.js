import styled from "styled-components";

export const MainContainer = styled.header`
display: flex;
align-items: center;
justify-content: center;
height: 15vh;
background-color: black;
color: #fff;
font-size: 2.5vw;
`