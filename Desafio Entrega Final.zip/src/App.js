import { RouterDom } from "./assets/router/RouterDom"
// import { Home } from "./pages/home/Home.jsx";


function App() {
  return (
    <div >
      <RouterDom/>


    </div>
  );
}

export default App;
